The folder "Uploads" is required for the demonstration "To File System" to work.
You can change this by changing the code in the demonstration.