
5/12/2004, SH

The attached files are AcquiLite configureation and log data.

mb-001.log is the log file.  Since this unit has only one input group (the pulses) it is all in one log file.

In comparison to an AcquiSuite, the system uploads to a database server and acts like an acquisuite with exactly one modbus device at address 1.

The loggerconfig.ini file has system settings.   This sample has a descrepancy.  The real log has LF marks only.  This sample has CR/LF.

The mb-001.ini file is the point configuration information. This sample has two descrepancies.  The real log has LF marks only.  This sample has CR/LF.  This version also shows a firmware bug in that the pulse multiplier values for inputs 1 through 4 are not included in the configuration.

The sample data is configured such that inputs 1 and 2 are grouped for KWH, KVARH, and are named as "ion6200" indicating what type of meter is attached.   inputs 3 and 4 are descrete inputs without grouping.  

