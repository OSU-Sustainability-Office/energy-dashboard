
8/9/2005, SH

The enclosed files are for the PML ion6200 meter, configureation and log data.

ion6200.log is the log file.  Note, text values use single quotes.  MS Excell defaults to double quotes when importing files. 


The ion6200.ini file is the point configuration information. This sample has one descrepancies.  The real log has LF marks only.  This sample has CR/LF. 

This meter was in demo mode to provide realistic values for all data points. 